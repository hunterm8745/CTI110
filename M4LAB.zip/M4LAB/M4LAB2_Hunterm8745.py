# Turtle graphics: initials
# 6/15/2017
# CTI-110 M4LAB1: Initials
# Matthew Hunter
#

#initialize
import turtle
win = turtle.Screen()

turtle.left(90)
turtle.forward(70)
turtle.right(170)
turtle.forward(70)
turtle.left(160)
turtle.forward(70)
turtle.right(170)
turtle.forward(70)
turtle.left(90)

turtle.penup()

turtle.forward(5)
turtle.left(90)

turtle.pendown()

turtle.forward(70)
turtle.left(180)
turtle.forward(35)
turtle.left(90)
turtle.forward(20)
turtle.left(90)
turtle.forward(35)
turtle.left(180)
turtle.forward(70)


# at the end, keep the window open until closed
win.mainloop()
