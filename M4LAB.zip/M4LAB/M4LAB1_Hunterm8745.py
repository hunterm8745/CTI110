# Turtle graphics: square and triangle
# 6/15/2017
# CTI-110 M4LAB1: Shapes
# Matthew Hunter
#

#initialize
import turtle
win = turtle.Screen()

for j in range(4):
    turtle.forward(75)
    turtle.left(90)

for n in range(3):
    turtle.forward(75)
    turtle.right(120)



# at the end, keep the window open until closed
win.mainloop()
