def hero_make(level):
    Str = 10
    Dex = 10
    Con = 10
    Int = 10
    Wis = 10
    Cha = 10
    x = 0

    print()
    print('what difficulty would you like to use.\n'
          'Very Easy, Easy, Normal, Hard, Very Hard.')
    print()

    dif = input()
    print()

    if dif == 'Very Easy' or dif == 'very easy':
        points2 = 30
    elif dif == 'Easy' or dif == 'easy':
        points2 = 25
    elif dif == 'Normal' or dif == 'normal':
        points2 = 20
    elif dif == 'Hard' or dif == 'hard':
        points2 = 15
    elif dif == 'Very Hard' or dif == 'very hard':
        points2 = 10

    if level >= 4 and level < 8:
        points2 += 1
    elif level >= 8 and level < 12:
        points2 += 2
    elif level >= 12 and level < 16:
        points2 += 3
    elif level >= 16 and level < 20:
        points2 += 4
    elif level == 20:
        points2 += 5

    print('All attributs start at 10 and are maxed at 20, before racial bonuses.')
    print()

    print('You have ', points2, ' points to spend.')
    print()

    while x != 1:
        points = int(input('How many points do you want to put in Strength? '))
        print()

        while points > points2 or points > 10:
            print('You have used too many points. You have', points2, 'left.')
            print()
            points = int(input('How many points do you want to put in Strength? '))
            print()

        points2 -= points
        Str += points

        print('You have', points2, 'left.')
        print()

        points = int(input('How many points do you want to put in Dexterity? '))
        print()

        while points > points2 or points > 10:
            print('You have used too many points. You have', points2, 'left.')
            print()
            points = int(input('How many points do you want to put in Dexterity? '))
            print()

        points2 -= points
        Dex += points

        print('You have', points2, 'left.')
        print()

        points = int(input('How many points do you want to put in Constitution? '))
        print()

        while points > points2 or points > 10:
            print('You have used too many points. You have', points2, 'left.')
            print()
            points = int(input('How many points do you want to put in Constitution? '))
            print()

        points2 -= points
        Con += points

        print('You have', points2, 'left.')
        print()

        points = int(input('How many points do you want to put in Intelligence? '))
        print()

        while points > points2 or points > 10:
            print('You have used too many points. You have', points2, 'left.')
            print()
            points = int(input('How many points do you want to put in Intelligence? '))
            print()

        points2 -= points
        Int += points

        print('You have', points2, 'left.')
        print()

        points = int(input('How many points do you want to put in Wisdom? '))
        print()

        while points > points2 or points > 10:
            print('You have used too many points. You have', points2, 'left.')
            print()
            points = int(input('How many points do you want to put in Wisdom? '))
            print()

        points2 -= points
        Wis += points

        print('You have', points2, 'left.')
        print()

        points = int(input('How many points do you want to but in Charisma? '))
        print()

        while points > points2 or points > 10:
            print('You have used too many points. You have', points2, 'left.')
            print()
            points = int(input('How many points do you want to but in Charisma? '))
            print()

        points2 -= points
        Cha += points

        if points2 != 0:
            print('you still have', points2, ' left to spend. Start again.')
        else:
            print('Str = ', Str)
            print('Dex = ', Dex)
            print('Con = ', Con)
            print('Int = ', Int)
            print('Wis = ', Wis)
            print('Cha = ', Cha)
            print()

            accept = input('Are these stats acceptable? (Y,N) ')
            if accept == 'Y' or accept == 'y' or accept == 'Yes' or accept == 'yes':
                x += 1
            elif accept == 'n' or accept == 'N' or accept == 'No' or accept == 'no':
                print()
            else:
                print('ERROR. INVALID RESPONSE.')
                print('AUTOMATIC RESET.')
                print()
    
    return Str, Dex, Con, Int, Wis, Cha
