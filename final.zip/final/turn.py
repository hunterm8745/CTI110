import random
import time
import hero
import enemies
import dice

def enemy_first(hero_hp, enemy_ac, hero_ac, hero_ab, hero_dmg_bonus, enemy_hp, enemy_ab, enemy_dmg_bonus):

    combat = ['attack', 'defend']
    enemy_action = ''
    hero_action = ''
    current_enemy_hp = enemy_hp
    current_hero_hp = hero_hp
    
    while current_hero_hp > 0 and current_enemy_hp > 0:
        
        print('Hero Health: ', current_hero_hp)
        print('enemy Health: ', current_enemy_hp)
        print()

        if enemy_action == 'defend':
            enemy_ac -= 4
        
        if current_enemy_hp < (enemy_hp / 2):
            heal = random.randint(1, 3)
            if heal == 1:
                print('Enemy heals.')
                num = dice.d8() + 4
                time.sleep(1)
                print('Enemy heals for ', num, ' health')
                current_enemy_hp += num
                print()
        else:
            enemy_action = random.choice(combat)
            if enemy_action == 'attack':
                print('Enemy Attacks')
                attack = dice.d20() + enemy_ab
                print()
                time.sleep(1)
                if (attack - enemy_ab) == 20:
                    print('Enemy Crit')
                    confirm = dice.d20() + enemy_ab
                    print()
                    time.sleep(1)
                    if confirm >= hero_ac:
                        print('Crit Confirmed')
                        damage = (dice.d8() + enemy_dmg_bonus) * 2
                        time.sleep(1)
                        print('You take ', damage, ' damage')
                        current_hero_hp -= damage
                        print()
                        time.sleep(1)
                    elif confirm < hero_ac:
                        print("Crit didn't Confirm")
                        damage = dice.d8() + enemy_dmg_bonus
                        time.sleep(1)
                        print('You take ', damage, ' damage')
                        current_hero_hp -= damage
                        print()
                        time.sleep(1)
                elif attack >= hero_ac and (attack - enemy_ab) != 20 :
                    print('Attack Hits')
                    damage = dice.d8() + enemy_dmg_bonus
                    time.sleep(1)
                    print('You take ', damage, ' damage')
                    current_hero_hp -= damage
                    print()
                    time.sleep(1)
                elif attack < hero_ac:
                    print('Attack Misses')
                    print()
                    time.sleep(1)
            elif enemy_action == 'defend':
                print('Enemy Defends. AC + 4')
                enemy_ac += 4
                print()
                time.sleep(1)
    
        if hero_action == 'defend':
            hero_ac -= 4

        print('Your turn. What would you like to do?')
        hero_action = input()
        print()

        if hero_action == 'heal' or hero_action == 'Heal' or hero_action == 'H' or hero_action == 'h':
            num = dice.d8() + 4 
            print('You heal for ', num, ' health')
            current_hero_hp += num
            print()
            time.sleep(1)
        elif hero_action == 'attack' or hero_action == 'Attack' or hero_action == 'A' or hero_action == 'a':
            attack = dice.d20() + hero_ab
            time.sleep(1)
            if (attack - hero_ab) == 20:
                print('You Crit')
                confirm = dice.d20() + hero_ab
                time.sleep(1)
                if confirm >= enemy_ac:
                    print('Crit Confirmed')
                    damage = (dice.d8() + hero_dmg_bonus) * 2
                    time.sleep(1)
                    print('Enemy takes ', damage, ' damage')
                    current_enemy_hp -= damage
                    print()
                    time.sleep(1)
                elif confirm < enemy_ac:
                    print("Crit didn't Confirm")
                    damage = dice.d8() + hero_dmg_bonus
                    time.sleep(1)
                    print('Enemy takes ', damage, ' damage')
                    current_enemy_hp -= damage
                    print()
                    time.sleep(1)
            elif attack >= enemy_ac and (attack - enemy_ab) != 20:
                print('Attack Hits')
                damage = 100
                time.sleep(1)
                print('Enemy takes ', damage, ' damage')
                current_enemy_hp -= damage
                print()
                time.sleep(1)
            elif attack < enemy_ac:
                print('Attack Misses')
                print()
                time.sleep(1)
        elif hero_action == 'defend' or hero_action == 'Defend' or hero_action == 'D' or hero_action == 'd':
            print('You defend. AC + 4')
            hero_ac += 4
            print()
            time.sleep(1)

    return current_enemy_hp, current_hero_hp

def hero_first(hero_hp, enemy_ac, hero_ac, hero_ab, hero_dmg_bonus, enemy_hp, enemy_ab, enemy_dmg_bonus):

    combat = ['attack', 'defend']
    enemy_action = ''
    hero_action = ''
    current_enemy_hp = enemy_hp
    current_hero_hp = hero_hp
    

    while current_hero_hp > 0 and current_enemy_hp > 0:
        
        print('Hero Health: ', current_hero_hp)
        print('enemy Health: ', current_enemy_hp)
        print()

        if hero_action == 'defend':
            hero_ac -= 4

        print('Your turn. What would you like to do?')
        hero_action = input()
        print()

        if hero_action == 'heal' or hero_action == 'Heal' or hero_action == 'H' or hero_action == 'h':
            num = dice.d8() + 4 
            print('You heal for ', num, ' health')
            current_hero_hp += num
            print()
            time.sleep(1)
        elif hero_action == 'attack' or hero_action == 'Attack' or hero_action == 'A' or hero_action == 'a':
            attack = dice.d20() + hero_ab
            time.sleep(1)
            if (attack - hero_ab) == 20:
                print('You Crit')
                confirm = dice.d20() + hero_ab
                time.sleep(1)
                if confirm >= enemy_ac:
                    print('Crit Confirmed')
                    damage = (dice.d8() + hero_dmg_bonus) * 2
                    time.sleep(1)
                    print('Enemy takes ', damage, ' damage')
                    current_enemy_hp -= damage
                    print()
                    time.sleep(1)
                elif confirm < enemy_ac:
                    print("Crit didn't Confirm")
                    damage = dice.d8() + hero_dmg_bonus
                    time.sleep(1)
                    print('Enemy takes ', damage, ' damage')
                    current_enemy_hp -= damage
                    print()
                    time.sleep(1)
            elif attack >= enemy_ac and (attack - enemy_ab) != 20:
                print('Attack Hits')
                damage = 100
                time.sleep(1)
                print('Enemy takes ', damage, ' damage')
                current_enemy_hp -= damage
                print()
                time.sleep(1)
            elif attack < enemy_ac:
                print('Attack Misses')
                print()
                time.sleep(1)
        elif hero_action == 'defend' or hero_action == 'Defend' or hero_action == 'D' or hero_action == 'd':
            print('You defend. AC + 4')
            hero_ac += 4
            print()
            time.sleep(1)

    
        if enemy_action == 'defend':
            enemy_ac -= 4
        
        if current_enemy_hp < (enemy_hp / 2):
            heal = random.randint(1, 3)
            if heal == 1:
                print('Enemy heals.')
                num = dice.d8() + 4
                time.sleep(1)
                print('Enemy heals for ', num, ' health')
                current_enemy_hp += num
                print()
        else:
            enemy_action = random.choice(combat)
            if enemy_action == 'attack':
                print('Enemy Attacks')
                attack = dice.d20() + enemy_ab
                print()
                time.sleep(1)
                if (attack - enemy_ab) == 20:
                    print('Enemy Crit')
                    confirm = dice.d20() + enemy_ab
                    print()
                    time.sleep(1)
                    if confirm >= hero_ac:
                        print('Crit Confirmed')
                        damage = (dice.d8() + enemy_dmg_bonus) * 2
                        time.sleep(1)
                        print('You take ', damage, ' damage')
                        current_hero_hp -= damage
                        print()
                        time.sleep(1)
                    elif confirm < hero_ac:
                        print("Crit didn't Confirm")
                        damage = dice.d8() + enemy_dmg_bonus
                        time.sleep(1)
                        print('You take ', damage, ' damage')
                        current_hero_hp -= damage
                        print()
                        time.sleep(1)
                elif attack >= hero_ac and (attack - enemy_ab) != 20 :
                    print('Attack Hits')
                    damage = dice.d8() + enemy_dmg_bonus
                    time.sleep(1)
                    print('You take ', damage, ' damage')
                    current_hero_hp -= damage
                    print()
                    time.sleep(1)
                elif attack < hero_ac:
                    print('Attack Misses')
                    print()
                    time.sleep(1)
            elif enemy_action == 'defend':
                print('Enemy Defends. AC + 4')
                enemy_ac += 4
                print()
                time.sleep(1)

    return current_enemy_hp, current_hero_hp
