import random
import dice
import enemies
import char_gen
import hero_gen
import hero
import turn

hero_level, hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus = hero.hero()
print()
enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus = enemies.orc()

def main(level, enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus,hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus):
    first = ''
    second = ''
    enemy_ini = enemy_ini_bonus + dice.d20()
    hero_ini = hero_ini_bonus + dice.d20()
    current_hero_hp = hero_hp
    current_enemy_hp = enemy_hp

    if enemy_ini > hero_ini:
        first = 'enemy'
        second = 'hero'
    elif enemy_ini < hero_ini:
        first = 'hero'
        second = 'enemy'
    elif enemy_ini == hero_ini:
        if enemy_ini_bonus > hero_ini_bonus:
            first = 'enemy'
            second = 'hero'
        elif enemy_ini_bonus < hero_ini_bonus:
            first = 'hero'
            second = 'enemy'
        elif enemy_ini_bonus == hero_ini_bonus:
            num = random.randint(1, 2)
            if num == 1:
                first = 'enemy'
                second = 'hero'
            elif num == 2:
                first = 'hero'
                second = 'enemy'

    print()
    print('Enemy initiative roll = ', enemy_ini)
    print('Hero initiative roll = ', hero_ini)
    print()
    print('first: ', first)
    print('second: ', second)
    print()


    if first == 'enemy':
        enemy_hp, hero_hp = turn.enemy_first(hero_hp, enemy_ac, hero_ac, hero_ab, hero_dmg_bonus, enemy_hp, enemy_ab, enemy_dmg_bonus)
    elif first == 'hero':
        enemy_hp, hero_hp = turn.hero_first(hero_hp, enemy_ac, hero_ac, hero_ab, hero_dmg_bonus, enemy_hp, enemy_ab, enemy_dmg_bonus)

    if enemy_hp <=0:
        print('CONGRATULATION!')
        print('YOU WON.')
        print('Play Again? (Y/N)')
        again = input()
        print()
        if again == 'y' or again == 'Y' or again == 'Yes' or again == 'yes':
            print('Keep current Hero?')
            keep = input()
            print()
            if keep == 'y' or keep == 'Y' or keep == 'Yes' or keep == 'yes':
                print('Keep current health?')
                health = input()
                print()
                if health == 'y' or health == 'Y' or health == 'Yes' or health == 'yes':
                    enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus = enemies.orc()
                    main(hero_level, enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus,hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus)
                elif health == 'n' or health == 'N' or health == 'No' or health == 'no':
                    hero_hp = char_gen.hp(hero_level, hero_con)
                    enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus = enemies.orc()
                    main(hero_level, enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus,hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus)
            elif keep == 'n' or keep == 'N' or keep == 'No' or keep == 'no':
                level, hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus = hero.hero()
                print()
                enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus = enemies.orc()
                main(hero_level, enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus,hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus)
        elif again == 'n' or again == 'N' or again == 'No' or again == 'no':
            exit()
             
    elif hero_hp <= 0:
        print('GAME OVER')
        print('Play Again? (Y/N)')
        again = input()
        if again == 'y' or again == 'Y' or again == 'Yes' or again == 'yes':
            print('Keep current Hero?')
            keep = input()
            print()
            if keep == 'y' or keep == 'Y' or keep == 'Yes' or keep == 'yes':
                print('Keep current health?')
                health = input()
                print()
                if health == 'y' or health == 'Y' or health == 'Yes' or health == 'yes':
                    enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus = enemies.orc()
                    main(hero_level, enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus,hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus)
                elif health == 'n' or health == 'N' or health == 'No' or health == 'no':
                    hero_hp = char_gen.hp(hero_con)
                    enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus = enemies.orc()
                    main(hero_level, enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus,hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus)
            elif keep == 'n' or keep == 'N' or keep == 'No' or keep == 'no':
                hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus = hero.hero()
                print()
                enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus = enemies.orc()
                main(hero_level, enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus,hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus)
        elif again == 'n' or again == 'N' or again == 'No' or again == 'no':
            exit()


main(hero_level, enemy_str, enemy_dex, enemy_con, enemy_int, enemy_wis, enemy_cha, enemy_hp, enemy_ini_bonus, enemy_bab, enemy_ac, enemy_ab, enemy_dmg_bonus,hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini_bonus, hero_bab, hero_ac, hero_ab, hero_dmg_bonus)
