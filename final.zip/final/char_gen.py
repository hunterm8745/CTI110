import random
import dice
    
def Str():
    num = random.randint(8,18)
    return num

def Dex():
    num = random.randint(8,18)
    return num

def Con():
    num = random.randint(8,18)
    return num

def Int():
    num = random.randint(8,18)
    return num

def Wis():
    num = random.randint(8,18)
    return num

def Cha():
    num = random.randint(8,18)
    return num

def ability_bonus(ability):
    if ability <= 10:
        ability_bonus = ((ability / 2) - 5)
        ability_bonus -= .5
    elif ability >= 11:
        ability_bonus = ((ability / 2) - 5)
    return int(ability_bonus)

def hp(level, con):
    x = 1
    hp = 10 + ability_bonus(con)
    while x != level:
        hp += (dice.d10() + ability_bonus(con))
        x += 1
    return hp
