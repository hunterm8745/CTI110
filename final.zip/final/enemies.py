import char_gen

def orc():
    t = 0
    x = 1

    level = int(input('What level is the orc? '))
    print()

    while level < 1:
        print('You cannot have a level below 1.')
        int(input('What level is the orc? '))

    while level > 20:
        print('You cannot have a level above 20.')
        int(input('What level is the orc? '))

    ran = input('Would you like randomize the Orcs ability scores? (Y/N) ')
    print()

    while t != 1:
        if ran == 'y' or ran =='Y' or ran == 'Yes' or ran == 'yes':
            orc_str = char_gen.Str() + 4
            orc_dex = char_gen.Dex()
            orc_con = char_gen.Con()
            orc_int = char_gen.Int() - 2
            orc_wis = char_gen.Wis() - 2 
            orc_cha = char_gen.Cha() - 2
            print('Orc Str = ', orc_str)
            print('Orc Dex = ', orc_dex)
            print('Orc Con = ', orc_con)
            print('Orc Int = ', orc_int)
            print('Orc Wis = ', orc_wis)
            print('Orc Cha = ', orc_cha)
            t += 1
        elif ran == 'n' or ran =='N' or ran == 'No' or ran == 'no':
            orc_str = 22
            orc_dex = 16
            orc_con = 16
            orc_int = 8
            orc_wis = 8
            orc_cha = 8
            print('Orc Str = ', orc_str)
            print('Orc Dex = ', orc_dex)
            print('Orc Con = ', orc_con)
            print('Orc Int = ', orc_int)
            print('Orc Wis = ', orc_wis)
            print('Orc Cha = ', orc_cha)
            t += 1
        else:
            print('Incorrect input.')
            ran = input('Would you like randomize the Orcs ability scores? (Y/N) ')

    print()

    orc_hp = char_gen.hp(level, orc_con)

    orc_ini = char_gen.ability_bonus(orc_dex)
    orc_bab = level
    orc_ac = 10 + 4 + char_gen.ability_bonus(orc_dex)
    orc_ab = orc_bab + char_gen.ability_bonus(orc_str)
    orc_dmg_bonus = char_gen.ability_bonus(orc_str)

    print()
    print('Orc Hp = ', orc_hp)
    print('Orc Initiative Bonus = ', orc_ini)
    print('Orc BAB = ', orc_bab)
    print('Orc Armor Class = ', orc_ac)
    print('Orc Attack Bonus = ', orc_ab)
    print('Orc Damage Bonus = ', orc_dmg_bonus)


    return orc_str, orc_dex, orc_con, orc_int, orc_wis, orc_cha, orc_hp, orc_ini, orc_bab, orc_ac, orc_ab, orc_dmg_bonus
