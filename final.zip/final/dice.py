import random

def d20():
    num = random.randint(1,20)
    return num

def d12():
    num = random.randint(1,12)
    return num

def d10():
    num = random.randint(1,10)
    return num

def d8():
    num = random.randint(1,8)
    return num

def d6():
    num = random.randint(1,6)
    return num

def d4():
    num = random.randint(1,4)
    return num
