import random
import char_gen
import hero_gen

def hero():
    t = 0
    
    level = int(input('What level are you? '))

    while level < 1:
        print('You cannot have a level below 1.')
        int(input('What level are you? '))

    while level > 20:
        print('You cannot have a level above 20.')
        int(input('What level are you? '))


    ran = input('Would you like to buy or randomize your stats? ')
    print()

    while t != 1:
        if ran == 'buy' or ran =='Buy' or ran == 'b' or ran == 'B':
            hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha = hero_gen.hero_make(level)

            print(hero_str)
            print(hero_dex)
            print(hero_con)
            print(hero_int)
            print(hero_wis)
            print(hero_cha)
            t += 1

        elif ran == 'randomize' or ran =='Randomize' or ran == 'R' or ran == 'r':
            hero_str = char_gen.Str()
            hero_dex = char_gen.Dex()
            hero_con = char_gen.Con()
            hero_int = char_gen.Int()
            hero_wis = char_gen.Wis()
            hero_cha = char_gen.Cha()

            print(hero_str)
            print(hero_dex)
            print(hero_con)
            print(hero_int)
            print(hero_wis)
            print(hero_cha)

            t += 1
            
        else:
            print('Incorrect input.')
            ran = input('Would you like to buy or randomize your stats? ')

    hero_hp = char_gen.hp(level, hero_con)
    hero_ini = char_gen.ability_bonus(hero_dex)
    hero_bab = level
    hero_ac = 10 + 6 + char_gen.ability_bonus(hero_dex)
    hero_ab = hero_bab + char_gen.ability_bonus(hero_str)
    hero_dmg_bonus = char_gen.ability_bonus(hero_str)

    print()
    print('hero Hp = ', hero_hp)
    print('hero Initiative Bonus = ', hero_ini)
    print('hero BAB = ', hero_bab)
    print('hero Armor Class = ', hero_ac)
    print('hero Attack Bonus = ', hero_ab)
    print('hero Damage Bonus = ', hero_dmg_bonus)

    return level, hero_str, hero_dex, hero_con, hero_int, hero_wis, hero_cha, hero_hp, hero_ini, hero_bab, hero_ac, hero_ab, hero_dmg_bonus
